export interface GeneratedImage {
  id: string;
  url: string;
  prompt: string;
  style: string;
  timestamp: number;
  isFavorite?: boolean;
}

export interface ImageStyle {
  value: string;
  label: string;
  description: string;
}

export interface ApiResponse {
  success: boolean;
  imageUrl?: string;
  error?: string;
}