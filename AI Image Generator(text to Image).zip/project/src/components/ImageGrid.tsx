import React from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { ImageCard } from './ImageCard';
import { GeneratedImage } from '../types';

interface ImageGridProps {
  images: GeneratedImage[];
  onToggleFavorite: (id: string) => void;
  onRegenerate: (prompt: string, style: string) => void;
  onImageClick: (image: GeneratedImage) => void;
}

export function ImageGrid({ images, onToggleFavorite, onRegenerate, onImageClick }: ImageGridProps) {
  if (images.length === 0) {
    return (
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        className="flex flex-col items-center justify-center py-16 text-center"
      >
        <motion.div
          className="w-24 h-24 mb-6 rounded-full bg-gradient-to-r from-purple-500/20 to-cyan-500/20 flex items-center justify-center"
          animate={{ rotate: [0, 360] }}
          transition={{ duration: 20, repeat: Infinity, ease: "linear" }}
        >
          <div className="w-12 h-12 rounded-full bg-gradient-to-r from-purple-500 to-cyan-500 opacity-50" />
        </motion.div>
        <h3 className="text-xl font-semibold text-white mb-2">No images yet</h3>
        <p className="text-gray-400">Generate your first AI image to get started!</p>
      </motion.div>
    );
  }

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6 p-6"
    >
      <AnimatePresence>
        {images.map((image) => (
          <ImageCard
            key={image.id}
            image={image}
            onToggleFavorite={onToggleFavorite}
            onRegenerate={onRegenerate}
            onImageClick={onImageClick}
          />
        ))}
      </AnimatePresence>
    </motion.div>
  );
}