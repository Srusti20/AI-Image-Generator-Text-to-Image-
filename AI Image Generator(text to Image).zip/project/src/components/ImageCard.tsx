import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Download, Heart, RotateCcw, Maximize2 } from 'lucide-react';
import { GeneratedImage } from '../types';
import { downloadImage } from '../utils/api';

interface ImageCardProps {
  image: GeneratedImage;
  onToggleFavorite: (id: string) => void;
  onRegenerate: (prompt: string, style: string) => void;
  onImageClick: (image: GeneratedImage) => void;
}

export function ImageCard({ image, onToggleFavorite, onRegenerate, onImageClick }: ImageCardProps) {
  const [imageLoaded, setImageLoaded] = useState(false);

  const handleDownload = (e: React.MouseEvent) => {
    e.stopPropagation();
    const filename = `ai-generated-${image.id}.jpg`;
    downloadImage(image.url, filename);
  };

  const handleFavorite = (e: React.MouseEvent) => {
    e.stopPropagation();
    onToggleFavorite(image.id);
  };

  const handleRegenerate = (e: React.MouseEvent) => {
    e.stopPropagation();
    onRegenerate(image.prompt, image.style);
  };

  return (
    <motion.div
      layout
      initial={{ opacity: 0, scale: 0.9 }}
      animate={{ opacity: 1, scale: 1 }}
      exit={{ opacity: 0, scale: 0.9 }}
      className="group relative bg-white/10 backdrop-blur-sm rounded-2xl border border-white/20 overflow-hidden shadow-xl hover:shadow-2xl transition-all duration-300"
      whileHover={{ y: -5 }}
    >
      <div className="aspect-square relative overflow-hidden cursor-pointer" onClick={() => onImageClick(image)}>
        <motion.img
          src={image.url}
          alt={image.prompt}
          className="w-full h-full object-cover"
          onLoad={() => setImageLoaded(true)}
          initial={{ opacity: 0 }}
          animate={{ opacity: imageLoaded ? 1 : 0 }}
          transition={{ duration: 0.5 }}
        />
        
        {!imageLoaded && (
          <div className="absolute inset-0 flex items-center justify-center bg-gray-800/50">
            <motion.div
              className="w-8 h-8 border-2 border-purple-400 border-t-transparent rounded-full"
              animate={{ rotate: 360 }}
              transition={{ duration: 1, repeat: Infinity, ease: "linear" }}
            />
          </div>
        )}

        <div className="absolute inset-0 bg-gradient-to-t from-black/50 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
        
        <motion.div
          className="absolute top-2 right-2 opacity-0 group-hover:opacity-100"
          initial={false}
          animate={{ opacity: 0 }}
          whileHover={{ opacity: 1 }}
        >
          <Maximize2 className="w-5 h-5 text-white" />
        </motion.div>
      </div>

      <div className="p-4">
        <p className="text-sm text-gray-300 line-clamp-2 mb-3">
          {image.prompt}
        </p>
        
        <div className="flex items-center justify-between">
          <span className="text-xs text-purple-400 bg-purple-500/20 px-2 py-1 rounded-full">
            {image.style}
          </span>
          
          <div className="flex items-center space-x-2">
            <motion.button
              onClick={handleFavorite}
              className={`p-2 rounded-lg transition-all duration-300 ${
                image.isFavorite 
                  ? 'bg-red-500/20 text-red-400' 
                  : 'bg-white/10 text-gray-400 hover:text-red-400'
              }`}
              whileHover={{ scale: 1.1 }}
              whileTap={{ scale: 0.9 }}
            >
              <Heart className={`w-4 h-4 ${image.isFavorite ? 'fill-current' : ''}`} />
            </motion.button>
            
            <motion.button
              onClick={handleRegenerate}
              className="p-2 bg-white/10 text-gray-400 hover:text-cyan-400 rounded-lg transition-all duration-300"
              whileHover={{ scale: 1.1 }}
              whileTap={{ scale: 0.9 }}
            >
              <RotateCcw className="w-4 h-4" />
            </motion.button>
            
            <motion.button
              onClick={handleDownload}
              className="p-2 bg-gradient-to-r from-purple-500/20 to-cyan-500/20 text-purple-400 hover:text-purple-300 rounded-lg transition-all duration-300"
              whileHover={{ scale: 1.1 }}
              whileTap={{ scale: 0.9 }}
            >
              <Download className="w-4 h-4" />
            </motion.button>
          </div>
        </div>
      </div>
    </motion.div>
  );
}