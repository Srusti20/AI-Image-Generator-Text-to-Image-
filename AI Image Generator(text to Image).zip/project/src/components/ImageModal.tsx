import React from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { X, Download, Heart, RotateCcw } from 'lucide-react';
import { GeneratedImage } from '../types';
import { downloadImage } from '../utils/api';

interface ImageModalProps {
  image: GeneratedImage | null;
  onClose: () => void;
  onToggleFavorite: (id: string) => void;
  onRegenerate: (prompt: string, style: string) => void;
}

export function ImageModal({ image, onClose, onToggleFavorite, onRegenerate }: ImageModalProps) {
  if (!image) return null;

  const handleDownload = () => {
    const filename = `ai-generated-${image.id}.jpg`;
    downloadImage(image.url, filename);
  };

  const handleFavorite = () => {
    onToggleFavorite(image.id);
  };

  const handleRegenerate = () => {
    onRegenerate(image.prompt, image.style);
    onClose();
  };

  return (
    <AnimatePresence>
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-4"
        onClick={onClose}
      >
        <motion.div
          initial={{ scale: 0.9, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          exit={{ scale: 0.9, opacity: 0 }}
          className="bg-white/10 backdrop-blur-sm rounded-2xl border border-white/20 p-6 max-w-4xl w-full max-h-[90vh] overflow-auto"
          onClick={(e) => e.stopPropagation()}
        >
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-xl font-semibold text-white">Generated Image</h2>
            <motion.button
              onClick={onClose}
              className="p-2 bg-white/10 hover:bg-white/20 rounded-lg transition-all duration-300"
              whileHover={{ scale: 1.1 }}
              whileTap={{ scale: 0.9 }}
            >
              <X className="w-5 h-5 text-white" />
            </motion.button>
          </div>

          <div className="grid md:grid-cols-2 gap-6">
            <div className="space-y-4">
              <img
                src={image.url}
                alt={image.prompt}
                className="w-full rounded-xl shadow-2xl"
              />
              
              <div className="flex items-center space-x-2">
                <motion.button
                  onClick={handleFavorite}
                  className={`flex-1 p-3 rounded-lg transition-all duration-300 ${
                    image.isFavorite 
                      ? 'bg-red-500/20 text-red-400' 
                      : 'bg-white/10 text-gray-400 hover:text-red-400'
                  }`}
                  whileHover={{ scale: 1.02 }}
                  whileTap={{ scale: 0.98 }}
                >
                  <Heart className={`w-5 h-5 mx-auto ${image.isFavorite ? 'fill-current' : ''}`} />
                </motion.button>
                
                <motion.button
                  onClick={handleRegenerate}
                  className="flex-1 p-3 bg-white/10 text-gray-400 hover:text-cyan-400 rounded-lg transition-all duration-300"
                  whileHover={{ scale: 1.02 }}
                  whileTap={{ scale: 0.98 }}
                >
                  <RotateCcw className="w-5 h-5 mx-auto" />
                </motion.button>
                
                <motion.button
                  onClick={handleDownload}
                  className="flex-1 p-3 bg-gradient-to-r from-purple-500/20 to-cyan-500/20 text-purple-400 hover:text-purple-300 rounded-lg transition-all duration-300"
                  whileHover={{ scale: 1.02 }}
                  whileTap={{ scale: 0.98 }}
                >
                  <Download className="w-5 h-5 mx-auto" />
                </motion.button>
              </div>
            </div>

            <div className="space-y-4">
              <div>
                <h3 className="text-sm font-medium text-gray-400 mb-2">Prompt</h3>
                <p className="text-white bg-white/10 rounded-lg p-3">{image.prompt}</p>
              </div>
              
              <div>
                <h3 className="text-sm font-medium text-gray-400 mb-2">Style</h3>
                <span className="inline-block text-purple-400 bg-purple-500/20 px-3 py-1 rounded-full text-sm">
                  {image.style}
                </span>
              </div>
              
              <div>
                <h3 className="text-sm font-medium text-gray-400 mb-2">Generated</h3>
                <p className="text-white">{new Date(image.timestamp).toLocaleString()}</p>
              </div>
            </div>
          </div>
        </motion.div>
      </motion.div>
    </AnimatePresence>
  );
}