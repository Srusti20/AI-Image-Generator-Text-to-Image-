import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Wand2, Shuffle, Loader2 } from 'lucide-react';
import toast from 'react-hot-toast';
import { generateImage } from '../utils/api';
import { IMAGE_STYLES, SURPRISE_PROMPTS } from '../utils/constants';
import { GeneratedImage } from '../types';

interface ImageGeneratorProps {
  onImageGenerated: (image: GeneratedImage) => void;
}

export function ImageGenerator({ onImageGenerated }: ImageGeneratorProps) {
  const [prompt, setPrompt] = useState('');
  const [selectedStyle, setSelectedStyle] = useState('realistic');
  const [isLoading, setIsLoading] = useState(false);

  const handleGenerate = async () => {
    if (!prompt.trim()) {
      toast.error('Please enter a description for your image');
      return;
    }

    setIsLoading(true);
    const loadingToast = toast.loading('Generating your image...');

    try {
      const result = await generateImage(prompt, selectedStyle);
      
      if (result.success && result.imageUrl) {
        const newImage: GeneratedImage = {
          id: Date.now().toString(),
          url: result.imageUrl,
          prompt,
          style: selectedStyle,
          timestamp: Date.now()
        };
        
        onImageGenerated(newImage);
        toast.success('Image generated successfully!', { id: loadingToast });
      } else {
        toast.error(result.error || 'Failed to generate image', { id: loadingToast });
      }
    } catch (error) {
      toast.error('An error occurred while generating the image', { id: loadingToast });
    } finally {
      setIsLoading(false);
    }
  };

  const handleSurpriseMe = () => {
    const randomPrompt = SURPRISE_PROMPTS[Math.floor(Math.random() * SURPRISE_PROMPTS.length)];
    setPrompt(randomPrompt);
    toast.success('Surprise prompt selected!');
  };

  return (
    <motion.div
      initial={{ y: 50, opacity: 0 }}
      animate={{ y: 0, opacity: 1 }}
      transition={{ delay: 0.2 }}
      className="max-w-4xl mx-auto p-6"
    >
      <div className="bg-white/10 backdrop-blur-sm rounded-2xl border border-white/20 p-8 shadow-2xl">
        <motion.div
          className="space-y-6"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.3 }}
        >
          {/* Prompt Input */}
          <div className="space-y-2">
            <label className="block text-sm font-medium text-gray-300">
              Describe your image
            </label>
            <div className="relative">
              <textarea
                value={prompt}
                onChange={(e) => setPrompt(e.target.value)}
                placeholder="Describe the image you want to generate..."
                className="w-full p-4 bg-white/10 border border-white/20 rounded-xl text-white placeholder-gray-400 resize-none focus:ring-2 focus:ring-purple-400 focus:border-transparent transition-all duration-300"
                rows={3}
                disabled={isLoading}
              />
              <motion.button
                onClick={handleSurpriseMe}
                className="absolute top-2 right-2 p-2 bg-gradient-to-r from-purple-500 to-cyan-500 rounded-lg hover:from-purple-600 hover:to-cyan-600 transition-all duration-300"
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                disabled={isLoading}
              >
                <Shuffle className="w-4 h-4 text-white" />
              </motion.button>
            </div>
          </div>

          {/* Style Selection */}
          <div className="space-y-2">
            <label className="block text-sm font-medium text-gray-300">
              Art Style
            </label>
            <select
              value={selectedStyle}
              onChange={(e) => setSelectedStyle(e.target.value)}
              className="w-full p-4 bg-white/10 border border-white/20 rounded-xl text-white focus:ring-2 focus:ring-purple-400 focus:border-transparent transition-all duration-300"
              disabled={isLoading}
            >
              {IMAGE_STYLES.map((style) => (
                <option key={style.value} value={style.value} className="bg-gray-800">
                  {style.label}
                </option>
              ))}
            </select>
          </div>

          {/* Generate Button */}
          <motion.button
            onClick={handleGenerate}
            disabled={isLoading || !prompt.trim()}
            className="w-full p-4 bg-gradient-to-r from-purple-600 to-cyan-600 hover:from-purple-700 hover:to-cyan-700 disabled:from-gray-600 disabled:to-gray-700 text-white font-semibold rounded-xl transition-all duration-300 flex items-center justify-center space-x-2"
            whileHover={{ scale: isLoading ? 1 : 1.02 }}
            whileTap={{ scale: isLoading ? 1 : 0.98 }}
          >
            {isLoading ? (
              <>
                <Loader2 className="w-5 h-5 animate-spin" />
                <span>Generating...</span>
              </>
            ) : (
              <>
                <Wand2 className="w-5 h-5" />
                <span>Generate Image</span>
              </>
            )}
          </motion.button>
        </motion.div>
      </div>
    </motion.div>
  );
}