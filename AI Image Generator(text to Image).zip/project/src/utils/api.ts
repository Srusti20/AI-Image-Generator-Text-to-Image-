import { ApiResponse } from '../types';

const API_KEY = import.meta.env.VITE_CLIPDROP_API_KEY;
const API_URL = 'https://clipdrop-api.co/text-to-image/v1';

export async function generateImage(prompt: string, style: string = 'realistic'): Promise<ApiResponse> {
  if (!API_KEY || API_KEY === 'your_clipdrop_api_key_here') {
    // Return a mock response for demo purposes
    return new Promise((resolve) => {
      setTimeout(() => {
        const mockImageUrl = `https://images.pexels.com/photos/1103970/pexels-photo-1103970.jpeg?auto=compress&cs=tinysrgb&w=512&h=512&fit=crop`;
        resolve({
          success: true,
          imageUrl: mockImageUrl
        });
      }, 2000);
    });
  }

  try {
    const formData = new FormData();
    formData.append('prompt', `${prompt} in ${style} style`);

    const response = await fetch(API_URL, {
      method: 'POST',
      headers: {
        'x-api-key': API_KEY,
      },
      body: formData,
    });

    if (response.ok) {
      const blob = await response.blob();
      const imageUrl = URL.createObjectURL(blob);
      return { success: true, imageUrl };
    } else {
      return { success: false, error: 'Failed to generate image' };
    }
  } catch (error) {
    return { success: false, error: 'Network error occurred' };
  }
}

export function downloadImage(url: string, filename: string) {
  const link = document.createElement('a');
  link.href = url;
  link.download = filename;
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
}