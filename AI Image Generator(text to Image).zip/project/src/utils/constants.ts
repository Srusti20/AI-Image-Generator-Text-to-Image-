export const IMAGE_STYLES: Array<{ value: string; label: string; description: string }> = [
  { value: 'realistic', label: '📸 Realistic', description: 'Photorealistic images' },
  { value: '3d-render', label: '🎯 3D Render', description: '3D rendered artwork' },
  { value: 'anime', label: '🎌 Anime', description: 'Anime/manga style' },
  { value: 'digital-art', label: '🎨 Digital Art', description: 'Digital painting style' },
  { value: 'oil-painting', label: '🖼️ Oil Painting', description: 'Classical oil painting' },
  { value: 'watercolor', label: '🎭 Watercolor', description: 'Watercolor painting' },
  { value: 'cyberpunk', label: '🌆 Cyberpunk', description: 'Futuristic cyberpunk' },
  { value: 'fantasy', label: '🧙 Fantasy', description: 'Fantasy artwork' }
];

export const SURPRISE_PROMPTS = [
  "A majestic dragon soaring through clouds at sunset",
  "Futuristic cityscape with flying cars and neon lights",
  "Mystical forest with glowing mushrooms and fairy lights",
  "Underwater palace with coral gardens and tropical fish",
  "Steampunk airship floating above Victorian London",
  "Crystal cave with rainbow reflections and magical crystals",
  "Ancient temple in a cherry blossom garden",
  "Space station orbiting a colorful nebula",
  "Enchanted library with floating books and magical orbs",
  "Desert oasis with palm trees under starry night sky"
];

export const STORAGE_KEYS = {
  GENERATED_IMAGES: 'generated_images',
  FAVORITES: 'favorite_images',
  THEME: 'theme_preference'
};