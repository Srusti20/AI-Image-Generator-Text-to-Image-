import React, { useState, useCallback } from 'react';
import { motion } from 'framer-motion';
import toast, { Toaster } from 'react-hot-toast';
import { Header } from './components/Header';
import { ImageGenerator } from './components/ImageGenerator';
import { ImageGrid } from './components/ImageGrid';
import { ImageModal } from './components/ImageModal';
import { useLocalStorage } from './hooks/useLocalStorage';
import { useTheme } from './hooks/useTheme';
import { GeneratedImage } from './types';
import { generateImage } from './utils/api';
import { STORAGE_KEYS } from './utils/constants';

function App() {
  const { theme } = useTheme();
  const [images, setImages] = useLocalStorage<GeneratedImage[]>(STORAGE_KEYS.GENERATED_IMAGES, []);
  const [selectedImage, setSelectedImage] = useState<GeneratedImage | null>(null);

  const handleImageGenerated = useCallback((newImage: GeneratedImage) => {
    setImages(prev => [newImage, ...prev]);
  }, [setImages]);

  const handleToggleFavorite = useCallback((id: string) => {
    setImages(prev => 
      prev.map(img => 
        img.id === id ? { ...img, isFavorite: !img.isFavorite } : img
      )
    );
  }, [setImages]);

  const handleRegenerate = useCallback(async (prompt: string, style: string) => {
    const loadingToast = toast.loading('Regenerating image...');

    try {
      const result = await generateImage(prompt, style);
      
      if (result.success && result.imageUrl) {
        const newImage: GeneratedImage = {
          id: Date.now().toString(),
          url: result.imageUrl,
          prompt,
          style,
          timestamp: Date.now()
        };
        
        handleImageGenerated(newImage);
        toast.success('Image regenerated successfully!', { id: loadingToast });
      } else {
        toast.error(result.error || 'Failed to regenerate image', { id: loadingToast });
      }
    } catch (error) {
      toast.error('An error occurred while regenerating the image', { id: loadingToast });
    }
  }, [handleImageGenerated]);

  const handleImageClick = useCallback((image: GeneratedImage) => {
    setSelectedImage(image);
  }, []);

  const handleCloseModal = useCallback(() => {
    setSelectedImage(null);
  }, []);

  return (
    <div className={`min-h-screen transition-colors duration-500 ${
      theme === 'dark' 
        ? 'bg-gradient-to-br from-gray-900 via-purple-900/20 to-cyan-900/20' 
        : 'bg-gradient-to-br from-gray-100 via-purple-100/50 to-cyan-100/50'
    }`}>
      <div className="relative">
        {/* Background Effects */}
        <motion.div
          className="absolute inset-0 overflow-hidden pointer-events-none"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 2 }}
        >
          <motion.div
            className="absolute top-1/4 left-1/4 w-72 h-72 bg-purple-500/10 rounded-full blur-3xl"
            animate={{ 
              x: [0, 100, 0],
              y: [0, -50, 0],
            }}
            transition={{ 
              duration: 20,
              repeat: Infinity,
              ease: "linear"
            }}
          />
          <motion.div
            className="absolute bottom-1/4 right-1/4 w-96 h-96 bg-cyan-500/10 rounded-full blur-3xl"
            animate={{ 
              x: [0, -100, 0],
              y: [0, 50, 0],
            }}
            transition={{ 
              duration: 25,
              repeat: Infinity,
              ease: "linear"
            }}
          />
        </motion.div>

        {/* Content */}
        <div className="relative z-10">
          <Header />
          
          <main className="pb-12">
            <ImageGenerator onImageGenerated={handleImageGenerated} />
            
            <motion.div
              className="max-w-7xl mx-auto"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 0.4 }}
            >
              <ImageGrid
                images={images}
                onToggleFavorite={handleToggleFavorite}
                onRegenerate={handleRegenerate}
                onImageClick={handleImageClick}
              />
            </motion.div>
          </main>
        </div>

        {/* Image Modal */}
        <ImageModal
          image={selectedImage}
          onClose={handleCloseModal}
          onToggleFavorite={handleToggleFavorite}
          onRegenerate={handleRegenerate}
        />

        {/* Toast Notifications */}
        <Toaster
          position="bottom-right"
          toastOptions={{
            duration: 4000,
            className: 'bg-white/10 backdrop-blur-sm text-white border border-white/20',
            style: {
              background: 'rgba(255, 255, 255, 0.1)',
              backdropFilter: 'blur(10px)',
              border: '1px solid rgba(255, 255, 255, 0.2)',
              color: 'white',
            },
          }}
        />
      </div>
    </div>
  );
}

export default App;